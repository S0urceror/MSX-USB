//------------------------------------------------
// targetconfig.h created automatically by make.sh
// on Sat 31 Jul 2021 22:11:30 CEST
//
// DO NOT BOTHER EDITING THIS.
// ALL CHANGES WILL BE LOST.
//------------------------------------------------

#ifndef  __TARGETCONFIG_H__
#define  __TARGETCONFIG_H__

//#define DEBUG
//#define OPENMSX_PROFILING

#endif //  __TARGETCONFIG_H__
