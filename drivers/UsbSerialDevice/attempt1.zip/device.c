#include "targetconfig.h"
#include "MSX/BIOS/msxbios.h"

#include <stdlib.h>
#include <stdint.h>
#include <stdbool.h>
#include "ch376s.h"
#include "device.h"
#include <string.h>
#include <ctype.h>
#include "descriptors.h"

uint8_t oneOneByte[1] = {1};
uint8_t oneZeroByte[1] = {0};
uint8_t twoZeroBytes[2] = {0,0};

#define min(X, Y) (((X) < (Y)) ? (X) : (Y))
char * strupr (char *str) 
{
  char *ret = str;

  while (*str)
    {
      *str = toupper (*str);
      ++str;
    }

  return ret;
}

#pragma disable_warning 85	// because the var msg is not used in C context
void _print(const char* msg) {
	__asm
		ld      hl, #2; retrieve address from stack
		add     hl, sp
		ld		b, (hl)
		inc		hl
		ld		h, (hl)
		ld		l, b

		_printMSG_loop :
		ld		a, (hl); print
		or		a
		ret z
		push	hl
		push	ix
		ld		iy, (#0xfcc0); BIOS_ROMSLT
		ld		ix, #0x00a2; BIOS_CHPUT
		call	#0x001c; BIOS_CALSLT
		pop		ix
		pop		hl
		inc		hl
		jr		_printMSG_loop
	__endasm;

	return;
}

void writeCommand (uint8_t data) __z88dk_fastcall __naked
{
    __asm
    ld a, l
    out (#0x11),a
    ret
    __endasm;
}
void writeData (uint8_t data) __z88dk_fastcall __naked
{
    __asm
    ld a, l
    out (#0x10),a
    ret
    __endasm;
}
uint8_t readData () __naked
{
    __asm
    in a, (#0x10)
    ld l, a
    ret
    __endasm;
}
uint8_t readStatus () __naked
{
    __asm
    in a, (#0x11)
    ld l, a
    ret
    __endasm;
}

#define JIFFY 50
#define SECOND JIFFY
#define MINUTE SECOND*60

void msx_enable_interrupt () __naked
{
    __asm
    ei
    ret
    __endasm;
}
void msx_disable_interrupt () __naked
{
    __asm
    di
    ret
    __endasm;
}
void msx_wait (uint16_t times_jiffy)  __z88dk_fastcall __naked
{
    __asm
; Wait a determined number of interrupts
; Input: BC = number of 1/framerate interrupts to wait
; Output: (none)
WAIT:
	halt        ; waits 1/50th or 1/60th of a second till next interrupt
	dec hl
	ld a,h
	or l
	jr nz, WAIT
	ret

    __endasm; 
}

// ----------------------------------------------------------
//	This is an example of using debug code in C.
//	This is only for the demo app.
//	You can safely remove it for your application.
void print(const char* msg) {
	_print(msg);
    msx_enable_interrupt ();
	return;
}

typedef	union _REQUEST_PACK{
	unsigned char  buffer[64];
	struct{
		uint8_t	    bmRequestType;  
		uint8_t	    bRequest;	
		uint16_t    wValue;		
		uint16_t    wIndx;		
		uint16_t    wLength;	
	}r;
} REQUEST_PACKET;

typedef union _UART_PARA
{
    uint8_t uart_para_buf[ 7 ];
    struct
    {
        uint8_t bBaudRate1; // Serial port baud rate (lowest bit)
        uint8_t bBaudRate2; // (second low)
        uint8_t bBaudRate3; // (second highest)
        uint8_t bBaudRate4; // (highest bit)
        uint8_t bStopBit; // Stop bit
        uint8_t bParityBit; // Parity bit
        uint8_t bDataBits; // Number of data bits
    } uart;
} UART_PARA;
UART_PARA uart_parameters;

uint8_t*    dataToTransfer;
int         dataLength;
uint8_t     usb_device_address;
uint8_t     usb_configuration_id;

void reset ()
{
    dataLength = 0;
    dataToTransfer = NULL;
    usb_device_address = 0;
    usb_configuration_id = 0;
}

void sendEP0ACK ()
{
    writeCommand (SET_ENDP3__TX_EP0);
    writeData (SET_ENDP_ACK);
}
void sendEP0NAK ()
{
    writeCommand (SET_ENDP3__TX_EP0);
    writeData (SET_ENDP_NAK);
}
void sendEP0STALL ()
{
    writeCommand (SET_ENDP3__TX_EP0);
    writeData (SET_ENDP_STALL);
}

void writeDataForEndpoint0()
{
    int amount = min (EP0_PIPE_SIZE,dataLength);

    // this is a data or status stage
    //printf("  Writing %d bytes of %d: ", amount,dataLength);    
    writeCommand(CH_CMD_WR_EP0);
    writeData(amount);
    for(int i=0; i<amount; i++) 
    {
        //printf("0x%02X ", dataToTransfer[i]);
        writeData(dataToTransfer[i]);
    }
    //printf("\r\n");

    dataToTransfer += amount;
    dataLength -= amount;
}

size_t read_usb_data (uint8_t* pBuffer)
{
    uint8_t value = 0;
    writeCommand(CH375_CMD_RD_USB_DATA_UNLOCK);
    value = readData();
    if (value==0)
        return 0;
    for (uint8_t i=0;i<value;i++)
        *(pBuffer+i) = readData();
    return value;
}

void set_target_device_address (uint8_t address)
{
    writeCommand (CH375_CMD_SET_USB_ADDR);
    writeData(address);
}

REQUEST_PACKET request;
int length;
char characterBuffer[255];
enum state_transaction 
{
    SETUP=0,
    DATA,
    STATUS
} transaction_state = STATUS;
    
void printInterruptName( uint8_t interruptCode)
{
    const char* name = NULL;

    switch(interruptCode) 
    {
        case USB_INT_BUS_RESET:
            name = "BUS_RESET";
            break;
        case USB_INT_EP0_SETUP:
            name = "EP0_SETUP";
            break;
        case USB_INT_EP0_OUT:
            name = "EP0_OUT";
            break;
        case USB_INT_EP0_IN:
            name = "EP0_IN";
            break;
        case USB_INT_EP1_OUT:
            name = "EP1_OUT";
            break;
        case USB_INT_EP1_IN:
            name = "EP1_IN";
            break;
        case USB_INT_EP2_OUT:
            name = "EP2_OUT";
            break;
        case USB_INT_EP2_IN:
            name = "EP2_IN";
            break;
        case USB_INT_USB_SUSPEND:
            name = "USB_SUSPEND";
            break;
        case USB_INT_WAKE_UP:
            name = "WAKE_UP";
            break;
   }

   if(name == NULL) 
   {
        print("Unknown interrupt received\r\n");
   }
   else 
   {
        print("Int: ");
        print(name);
        print("\r\n");
   }
 }

void handleInterrupt ()
{
    // get the type of interrupt
    writeCommand(CH375_CMD_GET_STATUS);
    uint8_t interruptType = readData ();

    if((interruptType & USB_BUS_RESET_MASK) == USB_INT_BUS_RESET)
        interruptType = USB_INT_BUS_RESET;

    //printInterruptName(interruptType);

    switch(interruptType)
    {
        case USB_INT_USB_SUSPEND:
            writeCommand(CH_CMD_ENTER_SLEEP);
            writeCommand (CH375_CMD_UNLOCK_USB);
            break;
        case USB_INT_BUS_RESET:
            //writeCommand (CH375_CMD_RESET_ALL);
            reset ();
            writeCommand (CH375_CMD_UNLOCK_USB);
            break;
        // control endpoint setup package
        case USB_INT_EP0_SETUP:
        {
            //if (transaction_state!=STATUS)
            //    print ("SETUP: >> previous transaction not completed <<\r\n");
            transaction_state = SETUP;
            //print ("SETUP\r\n");

            // read setup package
            int length = read_usb_data (request.buffer);
            //printf("  bmRequestType: 0x%02X\r\n", request.r.bmRequestType);
            //printf("  bRequest: %i\r\n", request.r.bRequest);
            //printf("  wValue: 0x%04X\r\n", request.r.wValue);
            //printf("  wIndex: 0x%04X\r\n", request.r.wIndx);
            //printf("  wLength: %03d\r\n", request.r.wLength);

            // initialize dataLength with length of setup package
            dataLength = request.r.wLength;

            if ((request.r.bmRequestType & USB_TYPE_MASK)==USB_TYPE_VENDOR)
            {
                //print("SETUP VENDOR request\r\n");
            }
            if ((request.r.bmRequestType & USB_TYPE_MASK)==USB_TYPE_CLASS)
            {
                //print("SETUP CLASS request\r\n");
                switch (request.r.bRequest)              // Analyze the class request code and process it
                {
                    case SET_LINE_CODING: 
                        // SET_LINE_CODING
                        // new encoding send in EP0_IN message
                        //print ("  SET_LINE_CODING\r\n");
                        break;
                    case GET_LINE_CODING: // GET_LINE_CODING
                        //printf ("  GET_LINE_CODING\r\n");
                        dataToTransfer = (uint8_t*) &uart_parameters;
                        dataLength = min ((uint16_t) sizeof(UART_PARA),request.r.wLength);;
                        break;
                    case SET_CONTROL_LINE_STATE: // SET_CONTROL_LINE_STATE
                        //print ("  SET_CONTROL_LINE_STATE\r\n");
                        sendEP0ACK ();
                        break;
                    default:
                        //error ("  Unsupported class command code");
                        //sendEP0STALL ();
                        break;
                }                    
            }
            if ((request.r.bmRequestType & USB_TYPE_MASK)==USB_TYPE_STANDARD)
            {
                //print("SETUP STANDARD request");
                if ((request.r.bmRequestType & USB_DIR_MASK) == USB_DIR_IN) // IN
                {
                    //print(" IN\r\n");
                    switch(request.r.bRequest)
                    {
                        case USB_REQ_GET_DESCRIPTOR:
                        {
                            //print("USB_REQ_GET_DESCRIPTOR: ");
                            switch (request.r.wValue>>8)
                            {
                                case USB_DESC_DEVICE: 
                                {
                                    //print("DEVICE\r\n");
                                    dataToTransfer = DevDes;
                                    dataLength = min ((uint16_t) sizeof(DevDes),request.r.wLength);
                                    break;
                                }
                                case USB_DESC_CONFIGURATION: 
                                {
                                    //print("CONFIGURATION\r\n");
                                    dataToTransfer = ConDes;
                                    dataLength = min ((uint16_t) sizeof(ConDes),request.r.wLength);
                                    break;
                                }
                                case USB_DESC_STRING: 
                                {
                                    //print("STRING: ");
                                    uint8_t stringIndex = request.r.wValue&0xff;  
                                    switch(stringIndex)
                                    {
                                        case 0: 
                                        {
                                            //print("Language\r\n");
                                            dataToTransfer = LangDes;
                                            dataLength = min ((uint16_t) sizeof(LangDes),request.r.wLength);
                                            break;
                                        }
                                        case STRING_DESC_PRODUCT: 
                                        {
                                            //print("Product\r\n");
                                            dataToTransfer = PRODUCER_Des;
                                            dataLength = min ((uint16_t) sizeof(PRODUCER_Des),request.r.wLength);
                                            break;
                                        }
                                        case STRING_DESC_MANUFACTURER: 
                                        {
                                            //print("Manufacturer\r\n");
                                            dataToTransfer = MANUFACTURER_Des;
                                            dataLength = min ((uint16_t) sizeof(MANUFACTURER_Des),request.r.wLength);
                                            break;
                                        }
                                        case STRING_DESC_SERIAL:
                                        {
                                            //print("Serial\r\n");
                                            dataToTransfer = PRODUCER_SN_Des;
                                            dataLength = min ((uint16_t) sizeof(PRODUCER_SN_Des),request.r.wLength);
                                            break;
                                        }
                                        default: 
                                        {
                                            //printf("Unknown! (%i)\r\n", stringIndex);
                                            //print("Unknown string!\r\n");
                                            break;
                                        }
                                    }
                                    break;
                                }
                            }
                            writeDataForEndpoint0();
                            break;                   
                        } 
                        case USB_REQ_GET_CONFIGURATION:
                            //print("USB_REQ_GET_CONFIGURATION\r\n");    
                            dataToTransfer = &usb_configuration_id;
                            dataLength = 1;
                            break;
                        case USB_REQ_GET_INTERFACE:
                            //print("USB_REQ_GET_INTERFACE\r\n");    
                            break;
                        case USB_REQ_GET_STATUS:
                            //print("USB_REQ_GET_STATUS\r\n");    
                            break;
                        default:
                            //printf("UNKNOWN IN REQUEST 0x%x\r\n", request.r.bRequest);  
                            //print("UNKNOWN IN REQUEST\r\n");    
                            break;
                    }
                }
                else // OUT
                {
                    //print(" OUT\r\n");
                    switch(request.r.bRequest)
                    {
                        case USB_REQ_SET_ADDRESS:
                        {  
                            usb_device_address = request.r.wValue;
                            //printf("  SET_ADDRESS: %i\r\n", usb_device_address);
                            //print("  SET_ADDRESS: \r\n");
                            sendEP0ACK ();
                            break;
                        }
                        case USB_REQ_SET_CONFIGURATION:
                        {
                            //printf("  USB_REQ_SET_CONFIGURATION %d\r\n",request.r.wValue);  
                            //print("  USB_REQ_SET_CONFIGURATION\r\n");  
                            if (request.r.wValue==USB_CONFIGURATION_ID) 
                                usb_configuration_id = request.r.wValue;
                            sendEP0ACK ();
                            break; 
                        }
                        case USB_REQ_SET_INTERFACE:
                        {
                            //print("  USB_REQ_SET_INTERFACE\r\n");  
                            break; 
                        }
                        case USB_REQ_CLEAR_FEATURE:
                        {
                            //print("  USB_REQ_CLEAR_FEATURE\r\n");  
                            break; 
                        }
                        default:
                            //printf("  UNKNOWN OUT REQUEST 0x%x\r\n", request.r.bRequest);    
                            //print("  UNKNOWN OUT REQUEST\r\n");    
                            break;
                    }
                }
            }
            break;
        }
        // control endpoint, handles follow-up on setup packets
        // Successful upload of control endpoint from device to host
        case USB_INT_EP0_IN:
        {
            if (transaction_state!=SETUP && transaction_state!=DATA) {
                //print ("IN: >> unexpected IN after STATUS <<\r\n");
                writeCommand (CH375_CMD_UNLOCK_USB);
                break;
            }
            if (dataLength==0) {
                transaction_state = STATUS;
                //print ("IN:STATUS\r\n");
            }
            else {
                transaction_state = DATA;
                //print ("IN:DATA\r\n");
            }
            
            switch(request.r.bRequest)
            {
                case USB_REQ_SET_ADDRESS:
                {
                    //printf("  Setting device address to: %d\r\n",usb_device_address);  
                    // it's time to set the new address
                    set_target_device_address (usb_device_address);
                    break;
                }
            }
            // write remaining data, or a zero packet to indicate end of transfer
            writeDataForEndpoint0 ();
            writeCommand (CH375_CMD_UNLOCK_USB);
            
            break;
        }
        // Control endpoint data is successfully downloaded to device
        case USB_INT_EP0_OUT:
        {
            if (transaction_state!=SETUP && transaction_state!=DATA) {
                //printf ("OUT: >> unexpected OUT after status<<\r\n");
                sendEP0STALL();
                writeCommand (CH375_CMD_UNLOCK_USB);
                break;
            }
            if (dataLength==0) {
                transaction_state = STATUS;
                //print ("OUT:STATUS\r\n");
            }
            else {
                transaction_state = DATA;
                //print ("OUT:DATA\r\n");
            }

            // save previous request before it's overwritten in the next step
            uint8_t current_request = request.r.bRequest;

            // read data send to us
            length = read_usb_data (request.buffer);

            //printf("  Read %i bytes: ", length);
            //for(int i=0; i<length; i++) 
            //{
            //    printf("0x%02X ", request.buffer[i]);
            //}
            //printf("\r\n");

            // handle data
            dataLength = 0;
            switch(current_request)
            {
                case SET_LINE_CODING:
                {
                    //print ("  Copy line encoding parameters \r\n");
                    //memcpy (&uart_parameters,request.buffer,length);
                    sendEP0ACK ();
                    break;
                }
                default:
                {
                    // absorb mode
                    break;
                }
            }
            break;  
        }
        // interrupt endpoint
        case USB_INT_EP1_IN:
            //print ("EP1 IN\r\n");
            writeCommand (CH375_CMD_UNLOCK_USB);
            break;
        case USB_INT_EP1_OUT:
            //print ("EP1 OUT\r\n");
            // read data send to us
            length = read_usb_data (request.buffer);
            //printf("  Read %i bytes: ", length);
            //for(int i=0; i<length; i++) 
            //{
            //    printf("0x%02X ", request.buffer[i]);
            //}
            //printf("\r\n");
            break;
        // bulk endpoint
        case USB_INT_EP2_IN:
            // interrupt send after writing to EP2 buffer 
            // when we do nothing data does get send
            writeCommand (CH375_CMD_UNLOCK_USB);
            break;
        case USB_INT_EP2_OUT:
            length = read_usb_data ((uint8_t*)characterBuffer);
            characterBuffer[length]='\0';
            //printf("  Read %i bytes: ", length);
            //for(int i=0; i<length; i++) 
            //{
            //    printf("0x%02X ", characterBuffer[i]);
            //}
            //printf("\r\n");

            // write back (echo)
            strupr (characterBuffer);
            // write characterbuffer to EP2
            length = strlen (characterBuffer);
            writeCommand (CH_CMD_WR_EP2);
            writeData (length);
            for (int i=0; i<length; i++)
                writeData (characterBuffer[i]);
            break;
        default:
            writeCommand (CH375_CMD_UNLOCK_USB);
            break;
    }
}

bool check_exists ()
{
    uint8_t value = 190;
    uint8_t new_value;
    writeCommand (CH375_CMD_CHECK_EXIST);
    writeData(value);
    new_value = readData ();
    value = value ^ 255;
    if (new_value != value)
        return false;
    return true;
}

bool set_usb_host_mode (uint8_t mode)
{
    writeCommand(CH375_CMD_SET_USB_MODE);
    writeData(mode);
    
    uint8_t value;
    for(int i=0; i!=200; i++ )
    {
        value = readData();
        if ( value == CH_ST_RET_SUCCESS )
            return true;
    }
    return false;
}

void main (void)
{
    print ("MSXUSB serial monitor\r\n");
    print ("=====================\r\n");
    if (!check_exists())
    {
        print ("CH376s not inserted\r\n");
        return;
    }

    writeCommand (CH375_CMD_RESET_ALL);
    msx_wait (SECOND);
    
    if (!set_usb_host_mode(CH375_USB_MODE_DEVICE_OUTER_FW))
    {
        print ("Device mode not succeeded\r\n");
        return;
    }
    
    print ("USB device initialized\r\n");

    while (true)
    {
        if ((readStatus() & 0x80) == 0) 
            handleInterrupt(); 
        //else 
        //    msx_wait (1);
    }

    return;
}

// ----------------------------------------------------------
//	This is a CALL handler example.
//	CALL CMD1
//
//	This is only for the demo app.
//	To disable the support for BASIC's CALL statement:
//	1) Set CALL_EXPANSION to _OFF in ApplicationSettings.txt
//	To completely remove the support for BASIC's CALL statement from the project:
//	1) Set CALL_EXPANSION to _OFF in ApplicationSettings.txt
//	2) Optionally, remove/comment all CALL_STATEMENT items in ApplicationSettings.txt
//	3) Remove all onCallXXXXX functions from this file
char* onCallMONITOR(char* param) {
    // seek end of command (0x00/EoL ou 0x3a/":")
	while ((*param != 0) && (*param != 0x3a)) {
		param++;
	}

	return param;
}

// ----------------------------------------------------------
//	This is a DEVICE getID handler example.
//	"DEV:"
//
//	This is only for the demo app.
//	To disable the support for BASIC's devices:
//	1) Set DEVICE_EXPANSION to _OFF in ApplicationSettings.txt
//	To completely remove the support for BASIC's devices from the project:
//	1) Set DEVICE_EXPANSION to _OFF in ApplicationSettings.txt
//	2) Optionally, remove / comment all DEVICE items in ApplicationSettings.txt
//	3) Remove all onDeviceXXXXX_getIdand onDeviceXXXXX_IO routines from this file
char onDeviceMON_getId() {
	print("The C handler for MON_getId says hi!\r\n\0");
	return 0;
}

// ----------------------------------------------------------
//	This is a DEVICE IO handler example.
//	"DEV:"
//
//	This is only for the demo app.
//	To disable the support for BASIC's devices:
//	1) Set DEVICE_EXPANSION to _OFF in ApplicationSettings.txt
//	To completely remove the support for BASIC's devices from the project:
//	1) Set DEVICE_EXPANSION to _OFF in ApplicationSettings.txt
//	2) Optionally, remove / comment all DEVICE items in ApplicationSettings.txt
//	3) Remove all onDeviceXXXXX_getIdand onDeviceXXXXX_IO routines from this file
void onDeviceMON_IO(char* param, char cmd) {
	print("The C handler for MON_IO says hi!\r\n\0");
}