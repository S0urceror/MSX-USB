//------------------------------------------------
// targetconfig.h created automatically by make.sh
// on Thu Jul 22 07:06:41 CEST 2021
//
// DO NOT BOTHER EDITING THIS.
// ALL CHANGES WILL BE LOST.
//------------------------------------------------

#ifndef  __TARGETCONFIG_H__
#define  __TARGETCONFIG_H__

